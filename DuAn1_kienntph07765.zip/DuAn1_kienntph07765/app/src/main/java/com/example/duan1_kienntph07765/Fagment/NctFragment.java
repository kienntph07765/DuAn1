package com.example.duan1_kienntph07765.Fagment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.duan1_kienntph07765.Adapter.GoiYAdapter;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.R;

import java.util.ArrayList;
import java.util.List;

public class NctFragment extends Fragment {
RecyclerView rcvnct;

  @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.nct_fragment, container, false);

    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        rcvnct =view.findViewById(R.id.rcvnct);
        super.onViewCreated(view, savedInstanceState);
        List<BaiHat> list=new ArrayList<>();
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        GoiYAdapter goiYAdapter=new GoiYAdapter(getContext(),list);
        rcvnct.setAdapter(goiYAdapter);
        rcvnct.setHasFixedSize(true);
        rcvnct.setLayoutManager(new LinearLayoutManager(getContext()));
    }


}
