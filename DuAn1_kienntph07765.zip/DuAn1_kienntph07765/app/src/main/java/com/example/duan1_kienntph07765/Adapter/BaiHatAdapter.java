package com.example.duan1_kienntph07765.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.R;

import java.util.List;


public class BaiHatAdapter extends RecyclerView.Adapter<BaiHatAdapter.viewholder> {
 private  List<BaiHat> list;

 public BaiHatAdapter(List<BaiHat> list) {
  this.list = list;
 }

 @NonNull
 @Override
 public viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
  View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bai_hat, viewGroup, false);
  return new viewholder(view);
 }

 @Override
 public void onBindViewHolder(@NonNull viewholder holder, int position) {
  BaiHat baiHat = list.get(position);
  holder.anh.setImageResource(baiHat.getAnh());
  holder.tenbaihat.setText(baiHat.getTenbaihat());
  holder.tacgia.setText(baiHat.getTacgia());
 }
 @Override
 public int getItemCount() {
  return list.size();
 }

 public static class viewholder extends RecyclerView.ViewHolder {
  public ImageView anh;
  public TextView tenbaihat, tacgia;
  public viewholder(@NonNull View itemView) {
   super(itemView);
   anh = itemView.findViewById(R.id.anh);
   tenbaihat = itemView.findViewById(R.id.tenbh);
   tacgia = itemView.findViewById(R.id.tacgia);
  }
 }
}

