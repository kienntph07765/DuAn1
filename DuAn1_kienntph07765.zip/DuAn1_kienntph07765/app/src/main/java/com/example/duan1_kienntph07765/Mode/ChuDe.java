package com.example.duan1_kienntph07765.Mode;

public class ChuDe {
    int image;
    String name;

    public ChuDe( int image, String name) {

        this.image = image;
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ChuDe() {
    }


}
