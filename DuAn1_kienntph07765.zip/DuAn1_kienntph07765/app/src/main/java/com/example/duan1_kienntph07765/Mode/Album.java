package com.example.duan1_kienntph07765.Mode;

public class Album {
    int image;
    String title;
    String tacgia;
    String time;

    public Album(int image, String title, String tacgia, String time) {
        this.image = image;
        this.title = title;
        this.tacgia = tacgia;
        this.time = time;
    }

    public Album() {
    }
    public Album(int image, String title, String tacgia) {
        this.image = image;
        this.title = title;
        this.tacgia = tacgia;

    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTacgia() {
        return tacgia;
    }

    public void setTacgia(String tacgia) {
        this.tacgia = tacgia;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
