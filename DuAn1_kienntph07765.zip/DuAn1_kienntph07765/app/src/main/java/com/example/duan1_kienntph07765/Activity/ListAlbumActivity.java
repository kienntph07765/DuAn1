package com.example.duan1_kienntph07765.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;

import com.example.duan1_kienntph07765.Adapter.AlbumAdapter;
import com.example.duan1_kienntph07765.Adapter.BaiHatAdapter;
import com.example.duan1_kienntph07765.Adapter.GoiYAdapter;
import com.example.duan1_kienntph07765.Mode.Album;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.R;

import java.util.ArrayList;
import java.util.List;

public class ListAlbumActivity extends AppCompatActivity {
    RecyclerView rvlistalbum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


}
