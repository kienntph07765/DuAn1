package com.example.duan1_kienntph07765.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.duan1_kienntph07765.Fagment.PagerFragment;
import com.example.duan1_kienntph07765.R;

public class ManHinhMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_hinh_menu);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new PagerFragment()).commit();
    }
}
