package com.example.duan1_kienntph07765.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.duan1_kienntph07765.Activity.PlayNhacActivity;
import com.example.duan1_kienntph07765.Mode.BXH;
import com.example.duan1_kienntph07765.R;

import java.util.List;

public class BXHAdapter extends RecyclerView.Adapter<BXHAdapter.viewholder> {
    Context context;
    List<BXH> list;

    public BXHAdapter(Context context, List<BXH> list) {
        this.list = list;
        this.context = context;
    }
    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bxh, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        BXH bxh = list.get(position);
        holder.image.setBackgroundResource(bxh.getImage());
        holder.title.setText(bxh.getTitle());
        holder.casi1.setText(bxh.getCasi1());
        holder.casi2.setText(bxh.getCasi2());
        holder.casi3.setText(bxh.getCasi3());
        holder.tenbaiat1.setText(bxh.getTenbaihat1());
        holder.tenbaihat2.setText(bxh.getTenbaihat2());
        holder.tenbaihat3.setText(bxh.getTenbaihat3());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        LinearLayout image;
        TextView title,casi1,casi2,casi3,tenbaiat1,tenbaihat2,tenbaihat3;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.image);
            title=itemView.findViewById(R.id.title);
            casi1=itemView.findViewById(R.id.casi1);
            casi2=itemView.findViewById(R.id.casi2);
            casi3=itemView.findViewById(R.id.casi3);
            tenbaiat1=itemView.findViewById(R.id.tenbaihat1);
            tenbaihat2=itemView.findViewById(R.id.tenbaihat2);
            tenbaihat3=itemView.findViewById(R.id.tenbaihat3);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    context.startActivity(new Intent(context, PlayNhacActivity.class));
                }
            });
        }
    }
}
