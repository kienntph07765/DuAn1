package com.example.duan1_kienntph07765.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.duan1_kienntph07765.Activity.ListAlbumActivity;
import com.example.duan1_kienntph07765.Activity.PlayListNhacActivity;
import com.example.duan1_kienntph07765.Activity.PlayNhacActivity;
import com.example.duan1_kienntph07765.Mode.Album;
import com.example.duan1_kienntph07765.R;

import java.util.List;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.viewholder> {
    Context context;
    List<Album> list;

    public AlbumAdapter(Context context, List<Album> list) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public AlbumAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_album, parent, false);
        return new AlbumAdapter.viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlbumAdapter.viewholder holder, int position) {
        Album album = list.get(position);
        holder.imagab.setBackgroundResource(album.getImage());
        holder.tvab.setText(album.getTitle());
        holder.tvtacgiaab.setText(album.getTacgia());
        holder.tvtime.setText(album.getTime());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        ImageView imagab;
        TextView tvab,tvtacgiaab,tvtime;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            imagab=itemView.findViewById(R.id.imagab);
            tvab=itemView.findViewById(R.id.tvab);
            tvtacgiaab=itemView.findViewById(R.id.tvtacgiaab);
            tvtime=itemView.findViewById(R.id.tvtime);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    context.startActivity(new Intent(context, PlayListNhacActivity.class));
            }
            });
        }
    }
}
