package com.example.duan1_kienntph07765.Mode;

public class BaiHat {
    int anh;
    String tenbaihat;
    String tacgia;

    public BaiHat(int anh, String tenbaihat, String tacgia) {
        this.anh = anh;
        this.tenbaihat = tenbaihat;
        this.tacgia = tacgia;
    }

    public BaiHat() {
    }

    public String getTenbaihat() {
        return tenbaihat;
    }

    public void setTenbaihat(String tenbaihat) {
        this.tenbaihat = tenbaihat;
    }

    public String getTacgia() {
        return tacgia;
    }

    public void setTacgia(String tacgia) {
        this.tacgia = tacgia;
    }

    public int getAnh() {
        return anh;
    }

    public void setAnh(int anh) {
        this.anh = anh;
    }
}
