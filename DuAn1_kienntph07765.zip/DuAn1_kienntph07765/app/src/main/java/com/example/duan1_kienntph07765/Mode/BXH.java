package com.example.duan1_kienntph07765.Mode;

public class BXH {
    int image;
    String title1;
    String tenbaihat1;
    String casi1;
    String tenbaihat2;
    String casi2;
    String tenbaihat3;
    String casi3;

    public BXH(int image, String title1,  String tenbaihat1, String casi1, String tenbaihat2, String casi2, String tenbaihat3, String casi3) {
        this.image = image;
        this.title1 = title1;

        this.tenbaihat1 = tenbaihat1;
        this.casi1 = casi1;
        this.tenbaihat2 = tenbaihat2;
        this.casi2 = casi2;
        this.tenbaihat3 = tenbaihat3;
        this.casi3 = casi3;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle1() {
        return title1;
    }

    public void setTitle1(String title1) {
        this.title1 = title1;
    }

    public String getTenbaihat1() {
        return tenbaihat1;
    }

    public void setTenbaihat1(String tenbaihat1) {
        this.tenbaihat1 = tenbaihat1;
    }

    public String getCasi1() {
        return casi1;
    }

    public void setCasi1(String casi1) {
        this.casi1 = casi1;
    }

    public String getTenbaihat2() {
        return tenbaihat2;
    }

    public void setTenbaihat2(String tenbaihat2) {
        this.tenbaihat2 = tenbaihat2;
    }

    public String getCasi2() {
        return casi2;
    }

    public void setCasi2(String casi2) {
        this.casi2 = casi2;
    }

    public String getTenbaihat3() {
        return tenbaihat3;
    }

    public void setTenbaihat3(String tenbaihat3) {
        this.tenbaihat3 = tenbaihat3;
    }

    public String getCasi3() {
        return casi3;
    }

    public void setCasi3(String casi3) {
        this.casi3 = casi3;
    }

    public BXH() {
    }
}
