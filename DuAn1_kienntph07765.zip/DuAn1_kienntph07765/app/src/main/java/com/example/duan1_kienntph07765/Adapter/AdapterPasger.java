package com.example.duan1_kienntph07765.Adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.duan1_kienntph07765.Fagment.AlbumFragment;
import com.example.duan1_kienntph07765.Fagment.BxhFragment;
import com.example.duan1_kienntph07765.Fagment.NctFragment;
import com.example.duan1_kienntph07765.Fagment.TrangChuFragment;

public class AdapterPasger extends FragmentStatePagerAdapter {
    public AdapterPasger(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment=null;
        switch (position){
            case 0:
                fragment=new TrangChuFragment();
                break;
            case 1:
                fragment=new AlbumFragment();
                break;
            case 2:
                fragment=new BxhFragment();
                break;
            case 3:
                fragment=new NctFragment();
                break;

        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 4;
    }
}

