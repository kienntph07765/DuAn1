package com.example.duan1_kienntph07765.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.Activity.PlayNhacActivity;
import com.example.duan1_kienntph07765.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

public class GoiYAdapter extends RecyclerView.Adapter<GoiYAdapter.viewholder> {
    Context context;
    List<BaiHat> list;
    public GoiYAdapter(Context context, List<BaiHat> list) {
        this.list = list;
        this.context = context;
    }
    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =LayoutInflater.from(parent.getContext()).inflate(R.layout.item_goiy, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        BaiHat baiHat =list.get(position);
        holder.anh.setImageResource(baiHat.getAnh());
        holder.tenbaihat.setText(baiHat.getTenbaihat());
        holder.casi.setText(baiHat.getTacgia());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        ImageView anh;
        TextView tenbaihat,casi;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            anh=itemView.findViewById(R.id.imggoiy);
            tenbaihat=itemView.findViewById(R.id.tenbaihat);
            casi=itemView.findViewById(R.id.casi);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    context.startActivity(new Intent(context, PlayNhacActivity.class));
                }
            });

        }
    }
}
