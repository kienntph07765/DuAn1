package com.example.duan1_kienntph07765.Fagment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.duan1_kienntph07765.Adapter.BXHAdapter;
import com.example.duan1_kienntph07765.Mode.BXH;
import com.example.duan1_kienntph07765.R;

import java.util.ArrayList;
import java.util.List;

public class BxhFragment extends Fragment {
    RecyclerView rcltopbaihat;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bxh_fragment, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rcltopbaihat =view.findViewById(R.id.rcltopbaihat);
        List<BXH> list=new ArrayList<>();
        list.add(new BXH(R.drawable.s,"US - UK","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        list.add(new BXH(R.drawable.s,"VIỆT NAM","RUN For Your Life","Tiffany Young","Ghost","Alan Walker","Losr Control","Fell"));
        list.add(new BXH(R.drawable.s,"TRUNG QUỐC","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        list.add(new BXH(R.drawable.s,"HÀN QUỐC","RUN For Your Life","Tiffany Young","Ghost","Alan Walker","Losr Control","Fell"));
        list.add(new BXH(R.drawable.s,"TÂY BA NHA","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        list.add(new BXH(R.drawable.s,"US - UK","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        list.add(new BXH(R.drawable.s,"VIỆT NAM","RUN For Your Life","Tiffany Young","Ghost","Alan Walker","Losr Control","Fell"));
        list.add(new BXH(R.drawable.s,"TRUNG QUỐC","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        list.add(new BXH(R.drawable.s,"HÀN QUỐC","RUN For Your Life","Tiffany Young","Ghost","Alan Walker","Losr Control","Fell"));
        list.add(new BXH(R.drawable.s,"TÂY BA NHA","Em Gì Ơi","JACK","Chạy Ngay Đi","Sơn Tùng","Cô Thắm Không Về","Hồ Quang Hiếu"));
        rcltopbaihat.setLayoutManager(new LinearLayoutManager(getContext()));
        BXHAdapter bxhAdapter=new BXHAdapter(getContext(),list);
        rcltopbaihat.setAdapter(bxhAdapter);
    }


}
