package com.example.duan1_kienntph07765.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.duan1_kienntph07765.Adapter.GoiYAdapter;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.R;

import java.util.ArrayList;
import java.util.List;

public class PlayListNhacActivity extends AppCompatActivity {
RecyclerView rvlistnhac;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_list_nhac);
        rvlistnhac.findViewById(R.id.rvlistnhac);
        List<BaiHat> list=new ArrayList<>();
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Người Lạ Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Người Lạ Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Người Lạ Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        GoiYAdapter adapterGoiY=new GoiYAdapter(this,list);
        rvlistnhac.setAdapter(adapterGoiY);
        rvlistnhac.setLayoutManager(new LinearLayoutManager(this));

    }


}

