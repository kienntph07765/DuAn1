package com.example.duan1_kienntph07765.MVP;

public interface LoginView {
    void login();
    void checkUsername();
    void checkPassword();
    void navigate();
}
