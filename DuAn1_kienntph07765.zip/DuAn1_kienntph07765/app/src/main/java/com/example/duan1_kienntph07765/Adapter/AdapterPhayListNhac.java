package com.example.duan1_kienntph07765.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.duan1_kienntph07765.Activity.PlayNhacActivity;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.R;

import java.util.List;


 public class AdapterPhayListNhac {

 }

