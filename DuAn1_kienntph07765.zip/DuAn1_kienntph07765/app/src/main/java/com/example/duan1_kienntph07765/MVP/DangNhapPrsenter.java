package com.example.duan1_kienntph07765.MVP;


public class DangNhapPrsenter {
    private LoginView loginView;

    public DangNhapPrsenter(LoginView loginView) {
        this.loginView = loginView;
    }

    public void Login(String usernam, String password) {
        if (usernam.isEmpty()) {
            loginView.checkUsername();
        } else if (password.isEmpty()) {
            loginView.checkPassword();
        } else if (usernam.equalsIgnoreCase("admin") &&
                password.equalsIgnoreCase("admin")) {
            loginView.navigate();
        }
    }
}
