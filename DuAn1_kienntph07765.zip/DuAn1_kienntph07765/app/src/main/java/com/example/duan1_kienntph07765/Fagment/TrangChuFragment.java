package com.example.duan1_kienntph07765.Fagment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ViewFlipper;

import com.example.duan1_kienntph07765.Adapter.AlbumAdapter;
import com.example.duan1_kienntph07765.Adapter.BaiHatAdapter;
import com.example.duan1_kienntph07765.Adapter.ChuDeAdapter;
import com.example.duan1_kienntph07765.Adapter.GoiYAdapter;
import com.example.duan1_kienntph07765.Mode.Album;
import com.example.duan1_kienntph07765.Mode.BaiHat;
import com.example.duan1_kienntph07765.Mode.ChuDe;
import com.example.duan1_kienntph07765.R;

import java.util.ArrayList;
import java.util.List;

public class TrangChuFragment extends Fragment {
    Context context;
    RecyclerView rvbaihat, realbum, reChuDe, reGioiY;
    ViewFlipper vfquangcao;
    private List<BaiHat> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.trang_chu_fragment, container, false);
        vfquangcao = view.findViewById(R.id.vfquangcao);
        vfquangcao.setAutoStart(true);
        vfquangcao.startFlipping();
        realbum = view.findViewById(R.id.realbum);
        rvbaihat=view.findViewById(R.id.rvbaihat);
        reGioiY = view.findViewById(R.id.reGioiY);
        reChuDe =  view.findViewById(R.id.reChuDe);
        realbum =view.findViewById(R.id.realbum);

        return view;    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<BaiHat> list = new ArrayList<>();
        list.add(new BaiHat(R.drawable.qc1, "Nhớ Mãi Bóng Lưng Thầy", "V.A"));
        list.add(new BaiHat(R.drawable.qc2, "Cho Thầy Cô Cho Mái Trường", "V.A"));
        list.add(new BaiHat(R.drawable.qc2, "Hát Mãi Tình Thầy Cô", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Em Gì Ơi", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Chúng Ta Không Cần nhau", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Nhớ Mãi Bóng Lưng Thầy", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Cho Thầy Cô Cho Mái Trường", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Hát Mãi Tình Thầy Cô", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Em Gì Ơi", "V.A"));
        list.add(new BaiHat(R.drawable.qc3, "Chúng Ta Không Cần nhau", "V.A"));
        BaiHatAdapter baiHatAdapter = new BaiHatAdapter(list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        rvbaihat.setHasFixedSize(true);
        rvbaihat.setAdapter(baiHatAdapter);
        rvbaihat.setLayoutManager(linearLayoutManager);
        album(view);
        chude(view);
        goiy(view);
    }

    private void album(View view) {
        List<Album> list = new ArrayList<>();
        list.add(new Album(R.drawable.s, "Em Gì Ơi", "Jack", "3:20"));
        list.add(new Album(R.drawable.s, "Chạy Ngay Đi", "Sơn Tùng", "4:20"));
        list.add(new Album(R.drawable.s, "Chúng Ta Không Thuộc Về Nhau", "Sơn Tùng", "3:20"));
        list.add(new Album(R.drawable.s, "Lối Nhỏ", "Đen Vâu", "3:54"));
        list.add(new Album(R.drawable.s, "Em Gì Ơi", "Jack", "3:20"));
        list.add(new Album(R.drawable.s, "Chạy Ngay Đi", "Sơn Tùng", "4:20"));
        list.add(new Album(R.drawable.s, "Em Gì Ơi", "Jack", "3:20"));
        list.add(new Album(R.drawable.s, "Chạy Ngay Đi", "Sơn Tùng", "4:20"));
        list.add(new Album(R.drawable.s, "Chúng Ta Không Thuộc Về Nhau", "Sơn Tùng", "3:20"));
        list.add(new Album(R.drawable.s, "Lối Nhỏ", "Đen Vâu", "3:54"));
        list.add(new Album(R.drawable.s, "Em Gì Ơi", "Jack", "3:20"));
        list.add(new Album(R.drawable.s, "Chạy Ngay Đi", "Sơn Tùng", "4:20"));
        GridLayoutManager gridLayoutManager=new GridLayoutManager(getContext(),1);
        gridLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        realbum.setLayoutManager(gridLayoutManager);
        AlbumAdapter albumAdapter=new AlbumAdapter(getContext(),list);
        realbum.setAdapter(albumAdapter);

    }
    private void chude(View view) {
        List<ChuDe> list=new ArrayList<>();
        list.add(new ChuDe(R.drawable.s,"Ngày Mưa"));
        list.add(new ChuDe(R.drawable.s,"Mùa Thu"));
        list.add(new ChuDe(R.drawable.s,"Mùa Đông"));
        list.add(new ChuDe(R.drawable.s,"Nhạc Pop"));
        GridLayoutManager manager=new GridLayoutManager(getContext(),2);
        manager.setOrientation(RecyclerView.HORIZONTAL);
        reChuDe.setLayoutManager(manager);
        ChuDeAdapter chuDeAdapter=new ChuDeAdapter(getContext(),list);
        reChuDe.setAdapter(chuDeAdapter);
    }
    private void goiy(View view) {
        List<BaiHat> list=new ArrayList<>();
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Em Gì Ơi","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Chúng Ta Không Thuộc Về Nhau","Sơn Tùng"));
        list.add(new BaiHat(R.drawable.s,"Lối Nhỏ","Đen Vâu"));
        list.add(new BaiHat(R.drawable.s,"Chạy Ngay Đi","Sơn Tùng"));
        GoiYAdapter goiYAdapter=new GoiYAdapter(getContext(),list);
        reGioiY.setAdapter(goiYAdapter);
        reGioiY.setHasFixedSize(true);
        reGioiY.setLayoutManager(new LinearLayoutManager(getContext()));
    }
}











