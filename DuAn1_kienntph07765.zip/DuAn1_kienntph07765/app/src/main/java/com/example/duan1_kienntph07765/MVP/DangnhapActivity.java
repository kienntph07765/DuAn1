package com.example.duan1_kienntph07765.MVP;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.duan1_kienntph07765.Activity.ManHinhMenuActivity;
import com.example.duan1_kienntph07765.R;

public class DangnhapActivity extends AppCompatActivity implements LoginView {
    private EditText edtUsername;
    private EditText edtPassWord;
    private DangNhapPrsenter loginPresenter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dangnhap);
        edtUsername = findViewById(R.id.edtUsername);
        edtPassWord = findViewById(R.id.edtPassword);
        loginPresenter = new DangNhapPrsenter(this);

    }

    @Override
    public void login() {

    }

    @Override
    public void checkUsername() {
        edtUsername.setError("nhap Username");

    }

    @Override
    public void checkPassword() {
        edtPassWord.setError("nhap PassWord");

    }

    @Override
    public void navigate() {
        Intent intent = new Intent(DangnhapActivity.this, ManHinhMenuActivity.class);
        startActivity(intent);
    }
    public void Login(View view) {
        String usernam = edtUsername.getText().toString();
        String password = edtPassWord.getText().toString();
        loginPresenter.Login(usernam,password);
        Intent intent = new Intent(DangnhapActivity.this, ManHinhMenuActivity.class);
        startActivity(intent);

    }
}
