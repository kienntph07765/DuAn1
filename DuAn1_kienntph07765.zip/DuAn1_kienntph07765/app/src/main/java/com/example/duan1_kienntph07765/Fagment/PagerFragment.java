package com.example.duan1_kienntph07765.Fagment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.duan1_kienntph07765.Adapter.AdapterPasger;
import com.example.duan1_kienntph07765.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PagerFragment extends Fragment {
    ViewPager body;
    BottomNavigationView Btitem;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pager_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        anhxa(view);
        AdapterPasger adapter = new AdapterPasger(getFragmentManager());
        body.setAdapter(adapter);
        Btitem.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.trangchu:
                        body.setCurrentItem(0);
                        break;
                    case R.id.album:
                        body.setCurrentItem(1);
                        break;
                    case R.id.bxh:
                        body.setCurrentItem(2);
                        break;
                    case R.id.nct:
                        body.setCurrentItem(3);
                        break;


                }
                return false;
            }
        });


        body.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                Btitem.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void anhxa(View view) {
        body = view.findViewById(R.id.body);
        Btitem = view.findViewById(R.id.Bottomitem);
    }

    }


