package com.example.duan1_kienntph07765.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.duan1_kienntph07765.Activity.ListAlbumActivity;
import com.example.duan1_kienntph07765.Activity.PlayNhacActivity;
import com.example.duan1_kienntph07765.Mode.ChuDe;
import com.example.duan1_kienntph07765.R;

import java.util.List;

public class ChuDeAdapter extends RecyclerView.Adapter<ChuDeAdapter.viewholder> {
    Context context;
    List<ChuDe> list;
    public ChuDeAdapter(Context context, List<ChuDe> list) {
        this.list = list;
        this.context = context;
    }
    @NonNull
    @Override
    public ChuDeAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chu_de, parent, false);
        return new ChuDeAdapter.viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChuDeAdapter.viewholder holder, int position) {
        ChuDe chuDe = list.get(position);
        holder.imgcd.setImageResource(chuDe.getImage());
        holder.tvcd.setText(chuDe.getName());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
       public ImageView imgcd;
      public TextView tvcd;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            imgcd=itemView.findViewById(R.id.imgcd);
            tvcd=itemView.findViewById(R.id.tvcd);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    context.startActivity(new Intent(context, ListAlbumActivity.class));
                }
            });

        }
    }
}
